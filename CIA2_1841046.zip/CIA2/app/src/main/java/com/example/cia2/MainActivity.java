package com.example.cia2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText username;
    private android.widget.EditText password;

    //private Button submit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById((R.id.password));
        //submit=(Button)findViewById(R.id.button2);

    }

    public void toastShow(View view) {
        Toast toast = Toast.makeText(this, "Username=admin\nPassword=1234", Toast.LENGTH_SHORT);
        toast.show();
    }

    public void new_activity(View view) {
        String user = username.getText().toString();
        String pass = password.getText().toString();
        if (user.equals("admin") && pass.equals("1234")) {
            Intent intent = new Intent(this, food.class);
            intent.putExtra("username", user);
            startActivity(intent);
        } else {
            Toast toast = Toast.makeText(this, "Incorrect Username or password", Toast.LENGTH_SHORT);
            toast.show();
            username.setText("");
            password.setText("");
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, 1);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.call:
                Intent i = new Intent(Intent.ACTION_CALL);
                i.setData(Uri.parse("tel:998638834"));    // default dial number
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Please grant the permission to call", Toast.LENGTH_SHORT).show();
                    requestPermission();
                } else {
                    startActivity(i);
                }
                break;
            case R.id.mail:
                Intent i1 = new Intent(Intent.ACTION_SEND);
                i1.setData(Uri.parse("email"));
                String[] s = {"support.android@gmail.com", "android_help@gmail.com"};
                i1.putExtra(Intent.EXTRA_EMAIL, s);
                i1.setType("message/rfc822");    //setting MIME Email Multipurpose Internet Mail Extensions
                Intent chooser = Intent.createChooser(i1, "Launch Email");
                startActivity(chooser);
                break;
            case R.id.locate_us:
                Intent i2 = new Intent(Intent.ACTION_VIEW);
                i2.setData(Uri.parse("geo: 12.972442, 77.580643"));
                Intent chooser1 = Intent.createChooser(i2, "Launch Maps");
                startActivity(chooser1);
                break;
        }

        return super.onOptionsItemSelected(item);
    }
}