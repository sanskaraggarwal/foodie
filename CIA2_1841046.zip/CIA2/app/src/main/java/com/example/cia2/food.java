package com.example.cia2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class food extends AppCompatActivity {
    TextView header,item,pricet;
    RadioButton veg,non;
    FragmentManager fm;
    FragmentTransaction t;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food);
        header=findViewById(R.id.textView2);
        fm=getSupportFragmentManager();
        final BlankFragment menu=new BlankFragment();
        String username=getIntent().getExtras().getString("username");
        header.setText("Welcome "+username+"! Choose an option to get menu");
        veg=findViewById(R.id.veg);
        non=findViewById(R.id.non);
        non.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t=fm.beginTransaction();
                Bundle b=new Bundle();
                b.putInt("i1",R.drawable.butter_chicken);
                b.putString("t1","Butter Chicken\nRs.300");
                b.putInt("p1",300);
                b.putInt("i2",R.drawable.chicken_lollipop);
                b.putString("t2","Chicken Lollipop\nRs.250");
                b.putInt("p2",250);
                b.putInt("i3",R.drawable.mutton_biryani);
                b.putString("t3","Mutton Biryani\nRs.350");
                b.putInt("p3",350);
                b.putInt("i4",R.drawable.tandoori_chicken);
                b.putString("t4","Tandoori Chicken\nRs.150");
                b.putInt("p4",150);
                menu.setArguments(b);
                t.replace(R.id.mainActivity,menu);
                t.addToBackStack(null);
                t.commit();
            }
        });
        veg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t=fm.beginTransaction();
                Bundle b=new Bundle();
                b.putInt("i1",R.drawable.pbm);
                b.putString("t1","Paneer Butter\nMasala\nRs.250");
                b.putInt("p1",250);
                b.putInt("i2",R.drawable.dum_aaloo);
                b.putString("t2","Dum Aloo\nRs.100");
                b.putInt("p2",100);
                b.putInt("i3",R.drawable.paneer_tikka);
                b.putString("t3","Paneer Tikka\nRs.200");
                b.putInt("p3",200);
                b.putInt("i4",R.drawable.veg_biryani);
                b.putString("t4","Veg. Biryani\nRs.280");
                b.putInt("p4",280);
                menu.setArguments(b);
                t.replace(R.id.mainActivity,menu);
                t.addToBackStack(null);
                t.commit();
            }
        });
        String name=getIntent().getExtras().getString("name");
        int price=getIntent().getExtras().getInt("price");
        item=findViewById(R.id.textView4);
        pricet=findViewById(R.id.textView5);
        item.setText(item.getText().toString()+"\n"+name);
        pricet.setText(pricet.getText().toString()+"\n"+String.valueOf(price));


    }
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, 1);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.call:
                Intent i = new Intent(Intent.ACTION_CALL);
                i.setData(Uri.parse("tel:998638834"));    // default dial number
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Please grant the permission to call", Toast.LENGTH_SHORT).show();
                    requestPermission();
                } else {
                    startActivity(i);
                }
                break;
            case R.id.mail:
                Intent i1 = new Intent(Intent.ACTION_SEND);
                i1.setData(Uri.parse("email"));
                String[] s = {"support.android@gmail.com", "android_help@gmail.com"};
                i1.putExtra(Intent.EXTRA_EMAIL, s);
                i1.setType("message/rfc822");    //setting MIME Email Multipurpose Internet Mail Extensions
                Intent chooser = Intent.createChooser(i1, "Launch Email");
                startActivity(chooser);
                break;
            case R.id.locate_us:
                Intent i2 = new Intent(Intent.ACTION_VIEW);
                i2.setData(Uri.parse("geo: 12.972442, 77.580643"));
                Intent chooser1 = Intent.createChooser(i2, "Launch Maps");
                startActivity(chooser1);
                break;
        }

        return super.onOptionsItemSelected(item);
    }

}