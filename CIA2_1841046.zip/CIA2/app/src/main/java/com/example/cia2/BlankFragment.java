package com.example.cia2;

import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class BlankFragment extends Fragment {
    ImageView i1,i2,i3,i4;
    TextView t1,t2,t3,t4;
    CardView c1,c2,c3,c4;
    FragmentManager fm;
    FragmentTransaction t;

    public BlankFragment() {

    }

      @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        View v=inflater.inflate(R.layout.fragment_blank, container, false);
        i1=v.findViewById(R.id.img1);
        i2=v.findViewById(R.id.img2);
        i3=v.findViewById(R.id.img3);
        i4=v.findViewById(R.id.img4);
        t1=v.findViewById(R.id.txt1);
        t2=v.findViewById(R.id.txt2);
        t3=v.findViewById(R.id.txt3);
        t4=v.findViewById(R.id.txt4);
        final bill menu=new bill();

        Bundle b=getArguments();
        final int iv1,iv2,iv3,iv4,p1,p2,p3,p4;
        final String tv1,tv2,tv3,tv4;
        tv1=b.getString("t1");
          tv2=b.getString("t2");
          tv3=b.getString("t3");
          tv4=b.getString("t4");
          iv1=b.getInt("i1");
          iv2=b.getInt("i2");
          iv3=b.getInt("i3");
          iv4=b.getInt("i4");
          p1=b.getInt("p1");
          p2=b.getInt("p2");
          p3=b.getInt("p3");
          p4=b.getInt("p4");

          i1.setImageResource(iv1);
          i2.setImageResource(iv2);
          i3.setImageResource(iv3);
          i4.setImageResource(iv4);
          t1.setText(tv1);
          t2.setText(tv2);
          t3.setText(tv3);
          t4.setText(tv4);


          c1=v.findViewById(R.id.item1);
          c2=v.findViewById(R.id.item2);
          c3=v.findViewById(R.id.item3);
          c4=v.findViewById(R.id.item4);
          c1.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {

                  Bundle b1=new Bundle();
                  b1.putString("name",tv1);
                  b1.putInt("price",p1);

              }
          });
          c2.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                  Bundle b1=new Bundle();
                  b1.putString("name",tv2);
                  b1.putInt("price",p2);
              }
          });
          c3.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                  Bundle b1=new Bundle();
                  b1.putString("name",tv3);
                  b1.putInt("price",p3);
              }
          });
          c4.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                  Bundle b1=new Bundle();
                  b1.putString("name",tv4);
                  b1.putInt("price",p4);
              }
          });
          return v;
    }
}