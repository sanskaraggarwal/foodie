package com.example.cia2;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class bill extends AppCompatActivity {



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.fragment_bill);
        final TextView t8= (TextView) findViewById(R.id.textView8);
        t8.setVisibility(View.INVISIBLE);




        Bundle b = getIntent().getExtras();
        if (b != null) {

            String name = b.getString("name");
            String price = b.getString("price");


            TextView t1= (TextView) findViewById(R.id.food);
            TextView t2=(TextView) findViewById(R.id.price);
            TextView t3=(TextView) findViewById(R.id.textView7);
            TextView t4=(TextView) findViewById(R.id.textView4);
            int p2= Integer.parseInt(price);

            t1.setText(name);
            t2.setText("Rs."+price);
            int result = Integer.parseInt(price);

            int total = result + 89;

            t3.setText("Rs. "+total);
            t4.setText(("Rs. 89"));



            Button c1 = (Button) findViewById(R.id.btnto);

            c1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    t8.setVisibility(View.VISIBLE);




                }
            });

        }
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, 1);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.call:
                Intent i = new Intent(Intent.ACTION_CALL);
                i.setData(Uri.parse("tel:998638834"));    // default dial number
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Please grant the permission to call", Toast.LENGTH_SHORT).show();
                    requestPermission();
                } else {
                    startActivity(i);
                }
                break;
            case R.id.mail:
                Intent i1 = new Intent(Intent.ACTION_SEND);
                i1.setData(Uri.parse("email"));
                String[] s = {"support.android@gmail.com", "android_help@gmail.com"};
                i1.putExtra(Intent.EXTRA_EMAIL, s);
                i1.setType("message/rfc822");    //setting MIME Email Multipurpose Internet Mail Extensions
                Intent chooser = Intent.createChooser(i1, "Launch Email");
                startActivity(chooser);
                break;
            case R.id.locate_us:
                Intent i2 = new Intent(Intent.ACTION_VIEW);
                i2.setData(Uri.parse("geo: 12.972442, 77.580643"));
                Intent chooser1 = Intent.createChooser(i2, "Launch Maps");
                startActivity(chooser1);
                break;
        }

        return super.onOptionsItemSelected(item);
    }
}