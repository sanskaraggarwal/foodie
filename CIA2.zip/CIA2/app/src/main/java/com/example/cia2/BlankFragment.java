package com.example.cia2;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class BlankFragment extends AppCompatActivity {

    FragmentManager fm;
    FragmentTransaction t;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.fragment_blank);




        Bundle b = getIntent().getExtras();
        if (b != null) {

            final String tv1 = b.getString("t1");
            final String tv2 = b.getString("t2");
            final String tv3 = b.getString("t3");
            final String tv4 = b.getString("t4");
            int i1 = b.getInt("i1");


            int i2 = b.getInt("i2");

            int i3 = b.getInt("i3");

            int i4 = b.getInt("i4");

            final String p1 = b.getString("p1");
            final String p2 = b.getString("p2");
            final String p3 = b.getString("p3");
            final String p4 = b.getString("p4");
            ImageView im1= (ImageView) findViewById(R.id.img1);
            ImageView im2= (ImageView) findViewById(R.id.img2);
            ImageView im3=(ImageView) findViewById(R.id.img3);
            ImageView im4=(ImageView) findViewById(R.id.img4);
            TextView t1= (TextView) findViewById(R.id.txt1);
            TextView t2=(TextView) findViewById(R.id.txt2);
            TextView t3=(TextView) findViewById(R.id.txt3);
            TextView t4=(TextView) findViewById(R.id.txt4);
            im2.setImageResource(i2);
            im3.setImageResource(i3);
            im4.setImageResource(i4);
            im1.setImageResource(i1);
            t1.setText(tv1);
            t2.setText(tv2);
            t3.setText(tv3);
            t4.setText(tv4);


            CardView c1 = (CardView) findViewById(R.id.item1);
            CardView c2 = (CardView) findViewById(R.id.item2);
            CardView c3 = (CardView) findViewById(R.id.item3);
            CardView c4 = (CardView) findViewById(R.id.item4);
            c1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(BlankFragment.this, bill.class);



                    i.putExtra("name",tv1);
                    i.putExtra("price",p1);
                    startActivity(i);




                }
            });
            c2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(BlankFragment.this, bill.class);



                    i.putExtra("name",tv2);
                    i.putExtra("price",p2);
                    startActivity(i);

                }
            });
            c3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(BlankFragment.this, bill.class);



                    i.putExtra("name",tv3);
                    i.putExtra("price",p3);
                    startActivity(i);

                }
            });
            c4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(BlankFragment.this, bill.class);



                    i.putExtra("name",tv4);
                    i.putExtra("price",p4);
                    startActivity(i);

                }
            });
        }
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, 1);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.call:
                Intent i = new Intent(Intent.ACTION_CALL);
                i.setData(Uri.parse("tel:998638834"));    // default dial number
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Please grant the permission to call", Toast.LENGTH_SHORT).show();
                    requestPermission();
                } else {
                    startActivity(i);
                }
                break;
            case R.id.mail:
                Intent i1 = new Intent(Intent.ACTION_SEND);
                i1.setData(Uri.parse("email"));
                String[] s = {"support.android@gmail.com", "android_help@gmail.com"};
                i1.putExtra(Intent.EXTRA_EMAIL, s);
                i1.setType("message/rfc822");    //setting MIME Email Multipurpose Internet Mail Extensions
                Intent chooser = Intent.createChooser(i1, "Launch Email");
                startActivity(chooser);
                break;
            case R.id.locate_us:
                Intent i2 = new Intent(Intent.ACTION_VIEW);
                i2.setData(Uri.parse("geo: 12.972442, 77.580643"));
                Intent chooser1 = Intent.createChooser(i2, "Launch Maps");
                startActivity(chooser1);
                break;
        }

        return super.onOptionsItemSelected(item);
    }
}