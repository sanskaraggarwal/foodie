package com.example.cia2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class food extends AppCompatActivity {
    TextView header,item,pricet;
    RadioButton veg,non;
    FragmentManager fm;
    FragmentTransaction t;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food);
        header=findViewById(R.id.textView2);


        String username=getIntent().getExtras().getString("username");
        header.setText("Welcome "+username+"! Choose an option to get menu");

        veg=findViewById(R.id.veg);
        non=findViewById(R.id.non);
        non.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(food.this, BlankFragment.class);


                i.putExtra("i1",R.drawable.butter_chicken);
                i.putExtra("t1","Butter Chicken\nRs.300");
                i.putExtra("p1","300");
                i.putExtra("i2",R.drawable.chicken_lollipop);
                i.putExtra("t2","Chicken Lollipop\nRs.250");
                i.putExtra("p2","250");
                i.putExtra("i3",R.drawable.mutton_biryani);
                i.putExtra("t3","Mutton Biryani\nRs.350");
                i.putExtra("p3","350");
                i.putExtra("i4",R.drawable.tandoori_chicken);
                i.putExtra("t4","Tandoori Chicken\nRs.150");
                i.putExtra("p4","150");

                startActivity(i);

            }
        });
        veg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(food.this, BlankFragment.class);

                Bundle b=new Bundle();
                i.putExtra("i1",R.drawable.pbm);
                i.putExtra("t1","Paneer Butter\nMasala\nRs.250");
                i.putExtra("p1","250");
                i.putExtra("i2",R.drawable.dum_aaloo);
                i.putExtra("t2","Dum Aloo\nRs.100");
                i.putExtra("p2","100");
                i.putExtra("i3",R.drawable.paneer_tikka);
                i.putExtra("t3","Paneer Tikka\nRs.200");
                i.putExtra("p3","200");
                i.putExtra("i4",R.drawable.veg_biryani);
                i.putExtra("t4","Veg. Biryani\nRs.280");
                i.putExtra("p4","280");

                startActivity(i);
            }
        });



    }
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, 1);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.call:
                Intent i = new Intent(Intent.ACTION_CALL);
                i.setData(Uri.parse("tel:998638834"));    // default dial number
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Please grant the permission to call", Toast.LENGTH_SHORT).show();
                    requestPermission();
                } else {
                    startActivity(i);
                }
                break;
            case R.id.mail:
                Intent i1 = new Intent(Intent.ACTION_SEND);
                i1.setData(Uri.parse("email"));
                String[] s = {"support.android@gmail.com", "android_help@gmail.com"};
                i1.putExtra(Intent.EXTRA_EMAIL, s);
                i1.setType("message/rfc822");    //setting MIME Email Multipurpose Internet Mail Extensions
                Intent chooser = Intent.createChooser(i1, "Launch Email");
                startActivity(chooser);
                break;
            case R.id.locate_us:
                Intent i2 = new Intent(Intent.ACTION_VIEW);
                i2.setData(Uri.parse("geo: 12.972442, 77.580643"));
                Intent chooser1 = Intent.createChooser(i2, "Launch Maps");
                startActivity(chooser1);
                break;
        }

        return super.onOptionsItemSelected(item);
    }

}